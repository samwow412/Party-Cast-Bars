---------------------------------------------------------------------------
-- Party Cast Bars
-- A clean cast bar attached to each raid-style party frame.
--
-- Secret-value rules this file follows (see warcraft.wiki.gg/wiki/Secret_Values):
--   * Another unit's cast info is secret. We NEVER compare, add, or index it.
--     Names/icons/booleans go straight into display "sinks" only:
--       FontString:SetText, Texture:SetTexture, Region:SetAlphaFromBoolean.
--   * Bar progress is driven by a DurationObject through
--     StatusBar:SetTimerDuration (UnitCastingDuration / UnitChannelDuration).
--   * Anything that might touch a secret is wrapped in pcall.
---------------------------------------------------------------------------
local ADDON, ns = ...
ns.ADDON = ADDON

local format, floor, max, min = string.format, math.floor, math.max, math.min
local pcall, type, pairs, ipairs, _G = pcall, type, pairs, ipairs, _G
local GetTime = GetTime
local _ -- throwaway for unused returns (keeps it out of the global table)

---------------------------------------------------------------------------
-- Defaults
---------------------------------------------------------------------------
local function C(r, g, b, a) return { r, g, b, a or 1 } end

ns.defaults = {
	enabled = true,
	includePlayer = true,
	framePattern = "CompactPartyFrameMember%d",
	frameCount = 5,

	-- position (bar point -> point on the party frame)
	point = "LEFT",
	relPoint = "RIGHT",
	x = 4,
	y = 0,
	width = 150,
	height = 18,
	matchHeight = false,
	scale = 1,
	alpha = 1,
	strata = "MEDIUM",

	-- bar
	texture = "Solid",
	castColor = C(1.0, 0.70, 0.0),
	channelColor = C(0.25, 0.80, 0.35),
	shieldColor = C(0.62, 0.62, 0.62),
	failColor = C(0.85, 0.20, 0.20),
	bgColor = C(0, 0, 0, 0.6),
	channelDrain = true,
	reverseFill = false,
	smooth = false,

	borderShow = true,
	borderSize = 1,
	borderColor = C(0, 0, 0, 1),

	spark = true,
	sparkWidth = 2,
	sparkColor = C(1, 1, 1, 0.8),

	showIcon = true,
	iconSide = "LEFT",

	-- text
	font = "Friz Quadrata TT",
	outline = "OUTLINE",
	textColor = C(1, 1, 1, 1),
	textInset = 4,
	showName = true,
	nameSize = 11,
	nameAlign = "LEFT",
	showTime = true,
	timeSize = 11,
	timeMode = "REMAINING",
	timeDecimals = 1,

	-- interrupted / failed flash
	showFail = true,
	failHold = 0.8,
	failFade = 0.4,
}

local function Merge(dst, src)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			Merge(dst[k], v)
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
end

function ns.ResetDefaults()
	local db = ns.db
	for k in pairs(db) do db[k] = nil end
	Merge(db, ns.defaults)
	ns.Refresh()
end

---------------------------------------------------------------------------
-- Media (LibSharedMedia is optional)
---------------------------------------------------------------------------
local LSM
local builtinTextures = {
	["Solid"] = "Interface\\Buttons\\WHITE8X8",
	["Blizzard"] = "Interface\\TargetingFrame\\UI-StatusBar",
}

function ns.GetTexturePath(name)
	if LSM then
		local p = LSM:Fetch("statusbar", name, true)
		if p then return p end
	end
	return builtinTextures[name] or builtinTextures.Solid
end

function ns.GetFontPath(name)
	if LSM then
		local p = LSM:Fetch("font", name, true)
		if p then return p end
	end
	return STANDARD_TEXT_FONT
end

local function ListToValues(list)
	local t = {}
	for _, n in ipairs(list) do t[n] = n end
	return t
end

function ns.TextureValues()
	if LSM then return ListToValues(LSM:List("statusbar")) end
	return { Solid = "Solid", Blizzard = "Blizzard" }
end

function ns.FontValues()
	if LSM then return ListToValues(LSM:List("font")) end
	return { ["Friz Quadrata TT"] = "Friz Quadrata TT" }
end

---------------------------------------------------------------------------
-- Feature detection
---------------------------------------------------------------------------
local hasDurationAPI = type(UnitCastingDuration) == "function"
	and type(UnitChannelDuration) == "function"
	and type(C_DurationUtil) == "table"
	and type(C_DurationUtil.CreateDuration) == "function"

local function TimerEnums()
	local interp, dir
	if Enum then
		interp = Enum.StatusBarInterpolation
		dir = Enum.StatusBarTimerDirection
	end
	return interp, dir
end

local FAILED_TEXT = _G.FAILED or "Failed"
local INTERRUPTED_TEXT = _G.INTERRUPTED or "Interrupted"

---------------------------------------------------------------------------
-- Cast lookup. Returns (durationObject | true, "cast" | "channel") or nil.
-- A DurationObject itself is not secret, so a plain truthiness test is safe.
---------------------------------------------------------------------------
local function GetDuration(unit)
	if hasDurationAPI then
		local d = UnitCastingDuration(unit)
		if d then return d, "cast" end
		d = UnitChannelDuration(unit)
		if d then return d, "channel" end
		return nil
	end
	-- Fallback: no duration objects. First return value is a string (maybe
	-- secret); boolean tests on non-boolean secrets are allowed.
	if UnitCastingInfo(unit) then return true, "cast" end
	if UnitChannelInfo(unit) then return true, "channel" end
	return nil
end

-- name, icon, notInterruptible: all may be secret. Never inspect them.
local function GetInfo(unit, kind)
	local name, icon, notInt
	if kind == "cast" then
		-- name, text, texture, startMS, endMS, isTradeSkill, castID, notInterruptible, spellID
		name, _, icon, _, _, _, _, notInt = UnitCastingInfo(unit)
	else
		-- name, text, texture, startMS, endMS, isTradeSkill, notInterruptible, spellID
		name, _, icon, _, _, _, notInt = UnitChannelInfo(unit)
	end
	return name, icon, notInt
end

---------------------------------------------------------------------------
-- Bar widget
---------------------------------------------------------------------------
local Bar = {}
local bars = {}
local MAX_BARS = 40

local EVENTS = {
	"UNIT_SPELLCAST_START",
	"UNIT_SPELLCAST_STOP",
	"UNIT_SPELLCAST_FAILED",
	"UNIT_SPELLCAST_INTERRUPTED",
	"UNIT_SPELLCAST_DELAYED",
	"UNIT_SPELLCAST_CHANNEL_START",
	"UNIT_SPELLCAST_CHANNEL_STOP",
	"UNIT_SPELLCAST_CHANNEL_UPDATE",
	"UNIT_SPELLCAST_INTERRUPTIBLE",
	"UNIT_SPELLCAST_NOT_INTERRUPTIBLE",
}

local function SetColorTex(tex, c)
	tex:SetColorTexture(c[1], c[2], c[3], c[4])
end

local function CreateBar(index)
	local bar = CreateFrame("Frame", "PartyCastBar" .. index, UIParent)
	for k, v in pairs(Bar) do bar[k] = v end
	bar.index = index
	bar:Hide()

	bar.bg = bar:CreateTexture(nil, "BACKGROUND")
	bar.border = {}
	for i = 1, 4 do bar.border[i] = bar:CreateTexture(nil, "BORDER") end
	bar.icon = bar:CreateTexture(nil, "ARTWORK")
	bar.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

	local sb = CreateFrame("StatusBar", nil, bar)
	bar.sb = sb
	sb:SetStatusBarTexture(builtinTextures.Solid)
	sb:SetMinMaxValues(0, 1)
	sb:SetValue(0)

	-- Grey "can't be interrupted" overlay, clipped to the fill by anchoring it
	-- to the status bar texture. Visibility comes from a (secret) boolean.
	bar.shield = sb:CreateTexture(nil, "ARTWORK", nil, 1)
	bar.shield:SetAlpha(0)

	bar.spark = sb:CreateTexture(nil, "OVERLAY")

	-- Red flash for interrupted / failed.
	bar.flash = bar:CreateTexture(nil, "ARTWORK", nil, 2)
	bar.flash:Hide()

	bar.textFrame = CreateFrame("Frame", nil, bar)
	bar.textFrame:SetFrameLevel(sb:GetFrameLevel() + 3)
	bar.name = bar.textFrame:CreateFontString(nil, "OVERLAY")
	bar.time = bar.textFrame:CreateFontString(nil, "OVERLAY")

	bar.fadeMul = 1
	bar:SetScript("OnEvent", Bar.OnEvent)

	if hasDurationAPI and not ns.testDurationOK then
		ns.testDurationOK = type(sb.SetTimerDuration) == "function"
		if not ns.testDurationOK then hasDurationAPI = false end
	end
	return bar
end

function Bar:ApplyStyle(h)
	local db = ns.db
	h = h or db.height
	self.curH = h
	local w = db.width
	local bs = db.borderShow and db.borderSize or 0
	local inner = max(1, h - 2 * bs)

	self:SetSize(w, h)
	self:SetScale(db.scale)
	self:SetFrameStrata(db.strata)

	-- border -----------------------------------------------------------
	local b = self.border
	for i = 1, 4 do
		SetColorTex(b[i], db.borderColor)
		b[i]:SetShown(bs > 0)
		b[i]:ClearAllPoints()
	end
	if bs > 0 then
		b[1]:SetPoint("TOPLEFT"); b[1]:SetPoint("TOPRIGHT"); b[1]:SetHeight(bs)
		b[2]:SetPoint("BOTTOMLEFT"); b[2]:SetPoint("BOTTOMRIGHT"); b[2]:SetHeight(bs)
		b[3]:SetPoint("TOPLEFT", 0, -bs); b[3]:SetPoint("BOTTOMLEFT", 0, bs); b[3]:SetWidth(bs)
		b[4]:SetPoint("TOPRIGHT", 0, -bs); b[4]:SetPoint("BOTTOMRIGHT", 0, bs); b[4]:SetWidth(bs)
	end

	-- background -------------------------------------------------------
	self.bg:ClearAllPoints()
	self.bg:SetPoint("TOPLEFT", bs, -bs)
	self.bg:SetPoint("BOTTOMRIGHT", -bs, bs)
	SetColorTex(self.bg, db.bgColor)

	-- icon -------------------------------------------------------------
	self.icon:ClearAllPoints()
	self.icon:SetSize(inner, inner)
	self.icon:SetPoint(db.iconSide, self, db.iconSide, db.iconSide == "LEFT" and bs or -bs, 0)
	self.icon:SetShown(db.showIcon)

	-- status bar + text frame share the same inner rectangle -----------
	local left = bs + ((db.showIcon and db.iconSide == "LEFT") and inner or 0)
	local right = bs + ((db.showIcon and db.iconSide == "RIGHT") and inner or 0)
	for _, f in ipairs({ self.sb, self.textFrame }) do
		f:ClearAllPoints()
		f:SetPoint("TOPLEFT", self, "TOPLEFT", left, -bs)
		f:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -right, bs)
	end
	self.flash:ClearAllPoints()
	self.flash:SetPoint("TOPLEFT", self, "TOPLEFT", left, -bs)
	self.flash:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -right, bs)
	SetColorTex(self.flash, db.failColor)

	local path = ns.GetTexturePath(db.texture)
	self.sb:SetStatusBarTexture(path)
	self.sb:SetReverseFill(db.reverseFill and true or false)
	local fill = self.sb:GetStatusBarTexture()

	self.shield:ClearAllPoints()
	self.shield:SetAllPoints(fill)
	self.shield:SetTexture(path)
	local sc = db.shieldColor
	self.shield:SetVertexColor(sc[1], sc[2], sc[3], 1)
	self.shieldAlpha = sc[4]

	-- spark ------------------------------------------------------------
	self.spark:ClearAllPoints()
	self.spark:SetSize(db.sparkWidth, inner)
	if db.reverseFill then
		self.spark:SetPoint("CENTER", fill, "LEFT", 0, 0)
	else
		self.spark:SetPoint("CENTER", fill, "RIGHT", 0, 0)
	end
	SetColorTex(self.spark, db.sparkColor)

	-- text -------------------------------------------------------------
	local fontPath = ns.GetFontPath(db.font)
	local flags = db.outline
	if not self.name:SetFont(fontPath, db.nameSize, flags) then
		self.name:SetFont(STANDARD_TEXT_FONT, db.nameSize, flags)
	end
	if not self.time:SetFont(fontPath, db.timeSize, flags) then
		self.time:SetFont(STANDARD_TEXT_FONT, db.timeSize, flags)
	end
	local tc = db.textColor
	self.name:SetTextColor(tc[1], tc[2], tc[3], tc[4])
	self.time:SetTextColor(tc[1], tc[2], tc[3], tc[4])

	local reserve = db.showTime and (db.timeSize * 3.2) or 0
	self.name:ClearAllPoints()
	self.name:SetPoint("LEFT", self.textFrame, "LEFT", db.textInset, 0)
	self.name:SetPoint("RIGHT", self.textFrame, "RIGHT", -(db.textInset + reserve), 0)
	self.name:SetJustifyH(db.nameAlign)
	self.name:SetWordWrap(false)
	self.time:ClearAllPoints()
	self.time:SetPoint("RIGHT", self.textFrame, "RIGHT", -db.textInset, 0)
	self.time:SetJustifyH("RIGHT")
	self.timeFmt = "%." .. db.timeDecimals .. "f"

	self.spark:SetShown(db.spark and self.active == true)
	self.name:SetShown(db.showName or self.flashing == true)
	self.time:SetShown(db.showTime)
end

-- Colour of the fill depends on cast vs channel.
function Bar:ApplyFillColor(kind)
	local c = (kind == "channel") and ns.db.channelColor or ns.db.castColor
	self.sb:SetStatusBarColor(c[1], c[2], c[3], c[4])
end

function Bar:StopFlash()
	if self.flashing then
		self.flashing = false
		self.flashT = 0
		self.flash:Hide()
		self.fadeMul = 1
		self.sb:Show()
		self.name:SetShown(ns.db.showName)
		self.time:SetShown(ns.db.showTime)
	end
end

-- Draw a cast. name / icon / notInt can be secret: sinks only.
function Bar:Begin(dur, kind, name, icon, notInt)
	local db = ns.db
	self:StopFlash()
	self.active = true
	self.kind = kind
	self.dur = dur
	self.manual = nil

	self.sb:Show()
	self:ApplyFillColor(kind)

	if hasDurationAPI and dur ~= true then
		local interp, dirE = TimerEnums()
		local iv = interp and (db.smooth and interp.ExponentialEaseOut or interp.Immediate) or nil
		local dv
		if dirE then
			dv = (kind == "channel" and db.channelDrain) and dirE.RemainingTime or dirE.ElapsedTime
		end
		self.sb:SetTimerDuration(dur, iv, dv)
	else
		self:BeginManual(kind)
	end

	-- display sinks ----------------------------------------------------
	if db.showName then self.name:SetText(name or "") else self.name:SetText("") end
	if db.showIcon then pcall(self.icon.SetTexture, self.icon, icon) end

	if type(notInt) == "boolean" then
		local a = self.shieldAlpha or 1
		if self.shield.SetAlphaFromBoolean then
			self.shield:SetAlphaFromBoolean(notInt, a, 0)
		elseif not (issecretvalue and issecretvalue(notInt)) then
			self.shield:SetAlpha(notInt and a or 0)
		else
			self.shield:SetAlpha(0)
		end
	else
		self.shield:SetAlpha(0)
	end

	self.spark:SetShown(db.spark)
	self.fadeMul = 1
	self:SetAlpha(db.alpha)
	self:Show()
	self:UpdateTime()
end

-- Fallback used only when the client has no duration objects.
function Bar:BeginManual(kind)
	local unit = self.unit
	local s, e
	if kind == "cast" then
		_, _, _, s, e = UnitCastingInfo(unit)
	else
		_, _, _, s, e = UnitChannelInfo(unit)
	end
	if type(s) == "number" and type(e) == "number"
		and not (issecretvalue and (issecretvalue(s) or issecretvalue(e))) then
		self.manual = { s = s / 1000, e = e / 1000 }
	else
		-- Unknown timing: show a full, static bar.
		self.sb:SetMinMaxValues(0, 1)
		self.sb:SetValue(1)
	end
end

function Bar:ManualTick(now)
	local m = self.manual
	if not m then return end
	local total = m.e - m.s
	if total <= 0 then return end
	self.sb:SetMinMaxValues(0, total)
	local elapsed = min(max(now - m.s, 0), total)
	if self.kind == "channel" and ns.db.channelDrain then
		self.sb:SetValue(total - elapsed)
	else
		self.sb:SetValue(elapsed)
	end
end

local function SetTimeText(self)
	local d = self.dur
	if self.manual then
		local m = self.manual
		local v = (ns.db.timeMode == "ELAPSED") and (GetTime() - m.s) or (m.e - GetTime())
		self.time:SetFormattedText(self.timeFmt, max(v, 0))
	elseif d and d ~= true then
		if ns.db.timeMode == "ELAPSED" then
			self.time:SetFormattedText(self.timeFmt, d:GetElapsedDuration())
		else
			self.time:SetFormattedText(self.timeFmt, d:GetRemainingDuration())
		end
	else
		self.time:SetText("")
	end
end

function Bar:UpdateTime()
	if not ns.db.showTime or self.flashing then return end
	if self.timeBroken then return end
	if not pcall(SetTimeText, self) then
		-- Client refused the (secret) number. Disable numbers, keep the bar.
		self.timeBroken = true
		self.time:SetText("")
		ns.timeBroken = true
	end
end

function Bar:End()
	self.active = false
	self.dur = nil
	self.manual = nil
	if not self.flashing then self:Hide() end
end

function Bar:Reset()
	self:StopFlash()
	self:End()
	self:Hide()
end

function Bar:ShowFail(text)
	local db = ns.db
	if not db.showFail or not self.allowed then return end
	self.active = false
	self.dur = nil
	self.manual = nil
	self.flashing = true
	self.flashT = db.failHold + db.failFade
	self.sb:Hide()
	self.spark:Hide()
	self.time:SetText("")
	self.flash:Show()
	self.name:SetText(text)
	self.name:Show()
	self.fadeMul = 1
	self:SetAlpha(db.alpha)
	self:Show()
end

function Bar:HasCast()
	return self.unit and GetDuration(self.unit) ~= nil
end

function Bar:Refresh()
	if ns.testing then return end
	local unit = self.unit
	if not unit or not self.allowed or not ns.db.enabled then
		return self:Reset()
	end
	local dur, kind = GetDuration(unit)
	if dur then
		local name, icon, notInt = GetInfo(unit, kind)
		self:Begin(dur, kind, name, icon, notInt)
	elseif self.active then
		self:End()
	end
end

function Bar.OnEvent(self, event)
	if ns.testing then return end
	if event == "UNIT_SPELLCAST_INTERRUPTED" then
		self:ShowFail(INTERRUPTED_TEXT)
	elseif event == "UNIT_SPELLCAST_FAILED" then
		-- FAILED also fires for spammed spells while another cast continues.
		if not self:HasCast() then self:ShowFail(FAILED_TEXT) end
	else
		self:Refresh()
	end
end

function Bar:BindUnit(unit)
	if self.unit == unit then return end
	self.unit = unit
	self:UnregisterAllEvents()
	if unit then
		for _, ev in ipairs(EVENTS) do
			pcall(self.RegisterUnitEvent, self, ev, unit)
		end
	end
	self:Reset()
	if unit then self:Refresh() end
end

---------------------------------------------------------------------------
-- Test / preview mode
---------------------------------------------------------------------------
local TEST_ICON = "Interface\\Icons\\INV_Misc_QuestionMark"

function Bar:TestStart(now)
	self.testStage = (self.testStage or self.index) + 1
	local mode = self.testStage % 4
	if mode == 0 then
		self.allowed = true
		self:ShowFail(INTERRUPTED_TEXT)
		self.testEnd = now + 99
		return
	end
	local kind = (mode == 2) and "channel" or "cast"
	local dur = 3
	self.testEnd = now + dur
	local d
	if hasDurationAPI then
		self.testDur = self.testDur or C_DurationUtil.CreateDuration()
		self.testDur:SetTimeFromStart(now, dur)
		d = self.testDur
	else
		d = true
	end
	self.unit = self.unit or "player"
	self:Begin(d, kind, (kind == "channel") and "Test Channel" or "Test Cast", TEST_ICON, mode == 3)
	if d == true then self.manual = { s = now, e = now + dur } end
end

function Bar:TestTick(now)
	if self.flashing then return end
	if not self.testEnd or now >= self.testEnd then self:TestStart(now) end
end

---------------------------------------------------------------------------
-- Driver: time text, flash fade, polling for missed STOP events
---------------------------------------------------------------------------
local driver = CreateFrame("Frame")
local acc, pollAcc = 0, 0
driver:SetScript("OnUpdate", function(_, elapsed)
	acc = acc + elapsed
	if acc < 0.04 then return end
	local dt = acc
	acc = 0
	pollAcc = pollAcc + dt
	local poll = false
	if pollAcc >= 0.1 then poll = true; pollAcc = 0 end
	local now = GetTime()
	local db = ns.db

	for i = 1, #bars do
		local bar = bars[i]
		if bar.flashing then
			bar.flashT = bar.flashT - dt
			if bar.flashT <= 0 then
				bar:StopFlash()
				bar:Hide()
				bar.testEnd = nil
			elseif bar.flashT < db.failFade and db.failFade > 0 then
				bar.fadeMul = bar.flashT / db.failFade
				bar:SetAlpha(db.alpha * bar.fadeMul)
			end
		elseif ns.testing and bar.allowed then
			bar:TestTick(now)
			if bar.manual then bar:ManualTick(now) end
			bar:UpdateTime()
		elseif bar.active then
			if bar.manual then bar:ManualTick(now) end
			bar:UpdateTime()
			if poll and not GetDuration(bar.unit) then bar:End() end
		end
	end
end)

---------------------------------------------------------------------------
-- Matching bars to party frames
---------------------------------------------------------------------------
ns.rev = 0

local function ResolveFrameName(pattern, i)
	local ok, name = pcall(format, pattern, i)
	if ok then return name end
end

local function FrameUnit(frame)
	local unit = frame.unit
	if type(unit) ~= "string" and frame.GetAttribute then
		local ok, u = pcall(frame.GetAttribute, frame, "unit")
		if ok then unit = u end
	end
	if type(unit) == "string" then return unit end
end

function ns.Sync()
	local db = ns.db
	if not db then return end
	local count = min(db.frameCount, MAX_BARS)

	for i = 1, MAX_BARS do
		local bar = bars[i]
		if i <= count and db.enabled then
			if not bar then
				bar = CreateBar(i)
				bars[i] = bar
				bar.rev = -1
			end
			local frame = _G[ResolveFrameName(db.framePattern, i) or ""]
			local usable = frame and frame:IsVisible() or false
			local unit
			if usable then
				unit = FrameUnit(frame)
				if unit and (not UnitExists(unit) or (unit == "player" and not db.includePlayer)) then
					unit = nil
				end
			end

			-- In preview mode every bar shows; without a visible party frame
			-- it floats near the middle of the screen instead.
			local floating = ns.testing and not usable
			bar.allowed = (unit ~= nil) or (ns.testing and true) or false

			-- height may follow the party frame
			local h = db.height
			if db.matchHeight and usable then
				local fh = frame:GetHeight()
				if type(fh) == "number" and not (issecretvalue and issecretvalue(fh)) and fh > 4 then
					h = fh
				end
			end

			if bar.rev ~= ns.rev or bar.curH ~= h then
				bar:ApplyStyle(h)
				bar.rev = ns.rev
				bar.anchorFrame = false
			end

			local target = (usable and frame) or (floating and "float") or nil
			if bar.anchorFrame ~= target then
				bar:ClearAllPoints()
				if usable then
					bar:SetPoint(db.point, frame, db.relPoint, db.x, db.y)
				elseif floating then
					bar:SetPoint("CENTER", UIParent, "CENTER", 0, 120 - (i - 1) * (h + 8))
				end
				bar.anchorFrame = target
			end

			if ns.testing then
				if not bar.unit then bar.unit = unit or "player" end
				if not bar.allowed then bar:Reset() end
			else
				bar:BindUnit(unit)
				if not unit then bar.allowed = false; bar:Reset() end
			end
		elseif bar then
			bar.allowed = false
			bar:BindUnit(nil)
			bar:Reset()
		end
	end
end

function ns.Refresh()
	ns.rev = ns.rev + 1
	ns.Sync()
	-- re-draw anything currently showing with the new look
	for i = 1, #bars do
		local bar = bars[i]
		if bar.active and not ns.testing then bar:Refresh() end
	end
end

function ns.SetTesting(on)
	ns.testing = on and true or false
	for i = 1, #bars do
		local bar = bars[i]
		bar.testEnd = nil
		bar:Reset()
		bar.anchorFrame = false -- force re-anchor
		if not ns.testing then bar.unit = nil end
	end
	ns.Sync()
end

function ns.ToggleTesting()
	ns.SetTesting(not ns.testing)
end

---------------------------------------------------------------------------
-- Events / slash commands
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("PLAYER_REGEN_DISABLED")
ev:SetScript("OnEvent", function(_, event, arg1)
	if event == "ADDON_LOADED" then
		if arg1 ~= ADDON then return end
		PartyCastBarsDB = PartyCastBarsDB or {}
		ns.db = PartyCastBarsDB
		Merge(ns.db, ns.defaults)
	elseif event == "PLAYER_LOGIN" then
		LSM = LibStub and LibStub("LibSharedMedia-3.0", true) or nil
		ns.LSM = LSM
		ns.Refresh()
		C_Timer.NewTicker(0.25, ns.Sync)
	elseif event == "PLAYER_REGEN_DISABLED" then
		if ns.testing then ns.SetTesting(false) end
	else
		ns.Sync()
	end
end)

local function Print(msg)
	print("|cff33ccffPartyCastBars|r: " .. msg)
end
ns.Print = Print

SLASH_PARTYCASTBARS1 = "/pcb"
SLASH_PARTYCASTBARS2 = "/partycastbars"
SlashCmdList["PARTYCASTBARS"] = function(msg)
	msg = (msg or ""):lower():match("^%s*(.-)%s*$")
	if msg == "test" then
		ns.ToggleTesting()
		Print(ns.testing and "test bars on (leave combat to see them)" or "test bars off")
	elseif msg == "diag" then
		local db = ns.db
		Print("duration API: " .. tostring(hasDurationAPI)
			.. ", LibSharedMedia: " .. tostring(ns.LSM ~= nil)
			.. ", time text blocked: " .. tostring(ns.timeBroken == true))
		for i = 1, min(db.frameCount, MAX_BARS) do
			local name = ResolveFrameName(db.framePattern, i) or "?"
			local f = _G[name]
			local b = bars[i]
			Print(format("%d: frame %s %s unit=%s active=%s", i, name,
				f and (f:IsVisible() and "(visible)" or "(hidden)") or "(NOT FOUND)",
				tostring(b and b.unit), tostring(b and b.active)))
		end
	elseif msg == "reset" then
		ns.ResetDefaults()
		Print("settings reset to defaults")
	else
		if ns.OpenOptions then ns.OpenOptions() end
	end
end
