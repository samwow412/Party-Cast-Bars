---------------------------------------------------------------------------
-- Party Cast Bars - settings GUI (AceConfig-3.0 / AceConfigDialog-3.0)
-- Open with /pcb
---------------------------------------------------------------------------
local ADDON, ns = ...

local APP = "PartyCastBars"
local AceConfig = LibStub("AceConfig-3.0")
local ACD = LibStub("AceConfigDialog-3.0")
local ACR = LibStub("AceConfigRegistry-3.0")

local POINTS = {
	TOPLEFT = "Top Left", TOP = "Top", TOPRIGHT = "Top Right",
	LEFT = "Left", CENTER = "Center", RIGHT = "Right",
	BOTTOMLEFT = "Bottom Left", BOTTOM = "Bottom", BOTTOMRIGHT = "Bottom Right",
}
local POINT_ORDER = {
	"TOPLEFT", "TOP", "TOPRIGHT", "LEFT", "CENTER", "RIGHT", "BOTTOMLEFT", "BOTTOM", "BOTTOMRIGHT",
}

local function get(info)
	return ns.db[info[#info]]
end

local function set(info, value)
	ns.db[info[#info]] = value
	ns.Refresh()
end

local function colorOption(order, name, key, hasAlpha, desc)
	return {
		type = "color",
		order = order,
		name = name,
		desc = desc,
		hasAlpha = hasAlpha and true or false,
		get = function()
			local c = ns.db[key]
			return c[1], c[2], c[3], c[4]
		end,
		set = function(_, r, g, b, a)
			ns.db[key] = { r, g, b, hasAlpha and a or 1 }
			ns.Refresh()
		end,
	}
end

local function preset(point, relPoint, x, y)
	return function()
		local db = ns.db
		db.point, db.relPoint, db.x, db.y = point, relPoint, x, y
		ns.Refresh()
		ACR:NotifyChange(APP)
	end
end

local options = {
	type = "group",
	name = "Party Cast Bars",
	childGroups = "tab",
	get = get,
	set = set,
	args = {
		----------------------------------------------------------------- General
		general = {
			type = "group",
			order = 1,
			name = "General",
			args = {
				enabled = {
					type = "toggle", order = 1, width = "full",
					name = "Enable cast bars",
				},
				includePlayer = {
					type = "toggle", order = 2, width = "full",
					name = "Show a bar for my own character",
					desc = "Raid-style party frames include you as the first frame.",
				},
				previewHeader = { type = "header", order = 10, name = "Preview" },
				previewInfo = {
					type = "description", order = 11, fontSize = "medium",
					name = "Shows demo casts, channels, non-interruptible casts and interrupts on every bar so you can style them. "
						.. "If no party frame is visible (for example while solo) the demo bars float near the middle of the screen. "
						.. "Preview turns itself off when you enter combat.",
				},
				preview = {
					type = "execute", order = 12, width = "double",
					name = function() return ns.testing and "Stop preview" or "Start preview" end,
					func = function()
						ns.ToggleTesting()
						ACR:NotifyChange(APP)
					end,
				},
				framesHeader = { type = "header", order = 20, name = "Party frames" },
				framesInfo = {
					type = "description", order = 21, fontSize = "medium",
					name = "Bars attach to frames named by the pattern below, where %d is replaced by 1, 2, 3... "
						.. "The default matches Blizzard's raid-style party frames. "
						.. "Use /fstack in game to find the frame names if you use a different frame addon, "
						.. "and /pcb diag to see which frames were found.",
				},
				framePattern = {
					type = "input", order = 22, width = "double",
					name = "Frame name pattern",
					desc = "Must contain %d.",
					validate = function(_, v)
						if type(v) ~= "string" or not v:find("%%d") then
							return "The pattern must contain %d"
						end
						return true
					end,
				},
				frameCount = {
					type = "range", order = 23, min = 1, max = 40, step = 1,
					name = "Number of frames",
					desc = "How many frames to try (5 covers a party plus yourself).",
				},
				resetHeader = { type = "header", order = 90, name = "Reset" },
				reset = {
					type = "execute", order = 91,
					name = "Reset all settings",
					confirm = true,
					confirmText = "Reset every Party Cast Bars setting to its default?",
					func = function()
						ns.ResetDefaults()
						ACR:NotifyChange(APP)
					end,
				},
			},
		},

		----------------------------------------------------------- Position & size
		position = {
			type = "group",
			order = 2,
			name = "Position & Size",
			args = {
				presetsHeader = { type = "header", order = 1, name = "Quick placement" },
				presetRight = {
					type = "execute", order = 2, name = "Right of frame",
					func = preset("LEFT", "RIGHT", 4, 0),
				},
				presetLeft = {
					type = "execute", order = 3, name = "Left of frame",
					func = preset("RIGHT", "LEFT", -4, 0),
				},
				presetBelow = {
					type = "execute", order = 4, name = "Below frame",
					func = preset("TOP", "BOTTOM", 0, -2),
				},
				presetAbove = {
					type = "execute", order = 5, name = "Above frame",
					func = preset("BOTTOM", "TOP", 0, 2),
				},
				anchorHeader = { type = "header", order = 10, name = "Anchor" },
				point = {
					type = "select", order = 11,
					name = "Bar anchor point",
					desc = "Which point of the cast bar is attached.",
					values = POINTS, sorting = POINT_ORDER,
				},
				relPoint = {
					type = "select", order = 12,
					name = "Party frame anchor point",
					desc = "Which point of the party frame the bar attaches to.",
					values = POINTS, sorting = POINT_ORDER,
				},
				x = {
					type = "range", order = 13, min = -300, max = 300, step = 1,
					name = "Horizontal offset",
				},
				y = {
					type = "range", order = 14, min = -300, max = 300, step = 1,
					name = "Vertical offset",
				},
				sizeHeader = { type = "header", order = 20, name = "Size" },
				width = {
					type = "range", order = 21, min = 40, max = 500, step = 1,
					name = "Width",
				},
				height = {
					type = "range", order = 22, min = 6, max = 80, step = 1,
					name = "Height",
					disabled = function() return ns.db.matchHeight end,
				},
				matchHeight = {
					type = "toggle", order = 23, width = "full",
					name = "Match party frame height",
					desc = "Use the height of the party frame instead of the fixed height above.",
				},
				scale = {
					type = "range", order = 24, min = 0.5, max = 2.5, step = 0.05,
					name = "Scale",
				},
				alpha = {
					type = "range", order = 25, min = 0.1, max = 1, step = 0.05,
					name = "Opacity", isPercent = true,
				},
				strata = {
					type = "select", order = 26,
					name = "Frame strata",
					values = {
						BACKGROUND = "Background", LOW = "Low", MEDIUM = "Medium",
						HIGH = "High", DIALOG = "Dialog",
					},
					sorting = { "BACKGROUND", "LOW", "MEDIUM", "HIGH", "DIALOG" },
				},
			},
		},

		---------------------------------------------------------------- Bar look
		bar = {
			type = "group",
			order = 3,
			name = "Bar",
			args = {
				fillHeader = { type = "header", order = 1, name = "Fill" },
				texture = {
					type = "select", order = 2, width = "double",
					name = "Texture",
					desc = "Install LibSharedMedia (any texture pack addon) for more choices.",
					values = function() return ns.TextureValues() end,
				},
				reverseFill = {
					type = "toggle", order = 3,
					name = "Reverse fill direction",
				},
				channelDrain = {
					type = "toggle", order = 4,
					name = "Channels drain",
					desc = "Channeled spells empty from full to zero instead of filling up.",
				},
				smooth = {
					type = "toggle", order = 5,
					name = "Smooth animation",
				},
				bgColor = colorOption(6, "Background color", "bgColor", true),

				borderHeader = { type = "header", order = 10, name = "Border" },
				borderShow = {
					type = "toggle", order = 11,
					name = "Show border",
				},
				borderSize = {
					type = "range", order = 12, min = 1, max = 6, step = 1,
					name = "Border size",
					disabled = function() return not ns.db.borderShow end,
				},
				sparkHeader = { type = "header", order = 20, name = "Spark" },
				spark = {
					type = "toggle", order = 21,
					name = "Show spark",
				},
				sparkWidth = {
					type = "range", order = 22, min = 1, max = 12, step = 1,
					name = "Spark width",
					disabled = function() return not ns.db.spark end,
				},
				sparkColor = colorOption(23, "Spark color", "sparkColor", true),

				iconHeader = { type = "header", order = 30, name = "Spell icon" },
				showIcon = {
					type = "toggle", order = 31,
					name = "Show spell icon",
				},
				iconSide = {
					type = "select", order = 32,
					name = "Icon side",
					values = { LEFT = "Left", RIGHT = "Right" },
					sorting = { "LEFT", "RIGHT" },
					disabled = function() return not ns.db.showIcon end,
				},
			},
		},

		------------------------------------------------------------------ Colors
		colors = {
			type = "group",
			order = 4,
			name = "Colors",
			args = {
				castColor = colorOption(1, "Cast", "castColor", true),
				channelColor = colorOption(2, "Channel", "channelColor", true),
				shieldColor = colorOption(
					3, "Not interruptible", "shieldColor", true,
					"Drawn over the fill when the spell cannot be interrupted."
				),
				failColor = colorOption(4, "Interrupted / failed", "failColor", true),
			},
		},

		------------------------------------------------------------------- Text
		text = {
			type = "group",
			order = 5,
			name = "Text",
			args = {
				fontHeader = { type = "header", order = 1, name = "Font" },
				font = {
					type = "select", order = 2, width = "double",
					name = "Font",
					desc = "Install LibSharedMedia (any media pack addon) for more choices.",
					values = function() return ns.FontValues() end,
				},
				outline = {
					type = "select", order = 3,
					name = "Outline",
					values = { [""] = "None", OUTLINE = "Thin", THICKOUTLINE = "Thick" },
					sorting = { "", "OUTLINE", "THICKOUTLINE" },
				},
				textColor = colorOption(4, "Text color", "textColor", true),
				textInset = {
					type = "range", order = 5, min = 0, max = 20, step = 1,
					name = "Text padding",
				},
				nameHeader = { type = "header", order = 10, name = "Spell name" },
				showName = {
					type = "toggle", order = 11,
					name = "Show spell name",
				},
				nameSize = {
					type = "range", order = 12, min = 6, max = 32, step = 1,
					name = "Size",
					disabled = function() return not ns.db.showName end,
				},
				nameAlign = {
					type = "select", order = 13,
					name = "Alignment",
					values = { LEFT = "Left", CENTER = "Center", RIGHT = "Right" },
					sorting = { "LEFT", "CENTER", "RIGHT" },
					disabled = function() return not ns.db.showName end,
				},
				timeHeader = { type = "header", order = 20, name = "Timer" },
				showTime = {
					type = "toggle", order = 21,
					name = "Show timer",
				},
				timeSize = {
					type = "range", order = 22, min = 6, max = 32, step = 1,
					name = "Size",
					disabled = function() return not ns.db.showTime end,
				},
				timeMode = {
					type = "select", order = 23,
					name = "Shows",
					values = { REMAINING = "Time remaining", ELAPSED = "Time elapsed" },
					sorting = { "REMAINING", "ELAPSED" },
					disabled = function() return not ns.db.showTime end,
				},
				timeDecimals = {
					type = "range", order = 24, min = 0, max = 2, step = 1,
					name = "Decimals",
					disabled = function() return not ns.db.showTime end,
				},
			},
		},

		------------------------------------------------------ Interrupts / failures
		fail = {
			type = "group",
			order = 6,
			name = "Interrupts",
			args = {
				showFail = {
					type = "toggle", order = 1, width = "full",
					name = "Flash when a cast is interrupted or fails",
				},
				failHold = {
					type = "range", order = 2, min = 0, max = 3, step = 0.1,
					name = "Hold time (seconds)",
					disabled = function() return not ns.db.showFail end,
				},
				failFade = {
					type = "range", order = 3, min = 0, max = 2, step = 0.1,
					name = "Fade time (seconds)",
					disabled = function() return not ns.db.showFail end,
				},
				failColorNote = {
					type = "description", order = 4,
					name = "The flash color is set on the Colors tab.",
				},
			},
		},
	},
}

-- (borderColor needs the helper above, so it is added after the table exists)
options.args.bar.args.borderColor = colorOption(13, "Border color", "borderColor", true)
options.args.bar.args.borderColor.disabled = function() return not ns.db.borderShow end

AceConfig:RegisterOptionsTable(APP, options)
ACD:SetDefaultSize(APP, 700, 620)
pcall(ACD.AddToBlizOptions, ACD, APP, "Party Cast Bars")

local function HookClose()
	-- Turn the preview off when the settings window closes.
	local f = ACD.OpenFrames and ACD.OpenFrames[APP]
	if f and f.frame and not f.frame.pcbHooked then
		f.frame.pcbHooked = true
		f.frame:HookScript("OnHide", function() ns.SetTesting(false) end)
	end
end

function ns.OpenOptions()
	ACD:Open(APP)
	pcall(HookClose)
end
